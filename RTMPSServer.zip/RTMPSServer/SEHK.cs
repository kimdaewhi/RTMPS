﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RTMPSServer
{
    class SEHK
    {
        /* DataTable Column Name */
        private string COL_POSITION_ID = "Position ID";
        private string COL_TICKER = "Ticker";
        private string COL_SPOT_PRICE = "Spot Price";
        private string COL_QTR_T1 = "Qty[T-1]";
        private string COL_QTR_T0 = "Qty[T-0]";
        private string COL_QTR_CHANGE = "Qty Change";

        private DataTable dtSEHK;
        public DataTable DtSEHK
        {
            get { return dtSEHK; }
        }


        public SEHK()
        {
            dtSEHK = new DataTable();
            CreateColumnOfSEHK();
            CreateDataOfSEHK();
        }


        /// <summary>
        /// Stock Exchange of Hong Kong DataTable 컬럼 Setting
        /// </summary>
        private void CreateColumnOfSEHK()
        {
            dtSEHK.TableName = "Stock Exchange of Hong Kong";
            dtSEHK.Columns.Add(COL_POSITION_ID, typeof(int));
            dtSEHK.Columns.Add(COL_TICKER, typeof(string));
            dtSEHK.Columns.Add(COL_SPOT_PRICE, typeof(decimal));

            dtSEHK.Columns.Add(COL_QTR_T1, typeof(int));
            dtSEHK.Columns.Add(COL_QTR_T0, typeof(int));
            dtSEHK.Columns.Add(COL_QTR_CHANGE, typeof(int));
        }

        /// <summary>
        /// 임의의 초기 데이터 설정
        /// </summary>
        private void CreateDataOfSEHK()
        {
            dtSEHK.Rows.Add(1, "700.HK" ,   321.600m, 1000   , 1500     , 500);
            dtSEHK.Rows.Add(2, "5.HK"   ,   57.300m , 10000  , 12000    , 2000);
            dtSEHK.Rows.Add(3, "941.HK" ,   65.000m , 50000  , 30000    , -20000);
            dtSEHK.Rows.Add(4, "2318.HK",   46.857m , 25000  , 31000    , 6000);
            dtSEHK.Rows.Add(5, "9988.HK",   90.800m , 90000  , 100000   , 10000);
            dtSEHK.Rows.Add(6, "939.HK" ,   4.290m  , 1000000, 850000   , -150000);
            dtSEHK.Rows.Add(7, "1299.HK",   67.577m , 5000   , 4000     , -1000);
            dtSEHK.Rows.Add(8, "3690.HK",   125.000m, 2700   , 2000     , -700);
            dtSEHK.Rows.Add(9, "1.HK"   ,   41.350m , 15000  , 20000    , 5000);
        }


        /// <summary>
        /// DataTable의 변동되는 값 설정(Spot Price, Qtr[T-0], Qtr Change)
        /// </summary>
        public void UpdateRandomDataOfSEHK()
        {
            Random random = new Random();
            decimal maxRdmVal = 0;
            decimal minRdmVal = 0;
            decimal rdmVal = 0;

            for (int i = 0; i < dtSEHK.Rows.Count; i++)
            {
                // 1초 주기로 변동하는 난수 생성

                // Spot Price
                decimal spotPrice = Convert.ToDecimal(dtSEHK.Rows[i][COL_SPOT_PRICE]);
                maxRdmVal = spotPrice * 0.15m;
                minRdmVal = spotPrice * -0.15m;
                rdmVal = Math.Round(minRdmVal + ((decimal)(random.NextDouble()) * (maxRdmVal - minRdmVal)));
                spotPrice = Math.Max(spotPrice + rdmVal, 1);

                // Qtr[T-0]
                int currQtyT0 = Convert.ToInt32(dtSEHK.Rows[i][COL_QTR_T0]);
                maxRdmVal = currQtyT0 * 0.15m;
                minRdmVal = currQtyT0 * -0.15m;
                rdmVal = Math.Round(minRdmVal + ((decimal)(random.NextDouble()) * (maxRdmVal - minRdmVal)));
                currQtyT0 = Math.Max(Convert.ToInt32(currQtyT0 + rdmVal), 1);

                // Qtr Change (Qtr[T-0] - Qtr[T-1])
                int currQtrChange = currQtyT0 - Convert.ToInt32(dtSEHK.Rows[i][COL_QTR_T1]);

                // 변경된 난수 적용
                dtSEHK.Rows[i][COL_SPOT_PRICE] = spotPrice;
                dtSEHK.Rows[i][COL_QTR_T0] = currQtyT0;
                dtSEHK.Rows[i][COL_QTR_CHANGE] = currQtrChange;
            }
        }



    }
}
