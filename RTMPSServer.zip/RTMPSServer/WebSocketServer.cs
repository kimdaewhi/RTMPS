﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Net.WebSockets;
using Newtonsoft.Json;
using System.Data;

namespace RTMPSServer
{
    class WebSocketServer
    {
        private HttpListener listener;                              // 리스너 인스턴스
        private List<WebSocket> clients = new List<WebSocket>();    // 연결된 클라이언트 관리용 List

        private SEHK sehk;                  // 송신 데이터

        private string sendData;            // 송신 데이터(Server >> Client)
        private string recvData;            // 수신 데이터(Client >> Server)

        private TextBox logTextBox;
        private Label clientCntLbl;


        public string SendData { get => sendData; }
        public string RecvData { get => recvData; }

        public WebSocketServer(TextBox logTextBox, Label clientCntLbl)
        {
            sehk = new SEHK();

            listener = new HttpListener();
            listener.Prefixes.Add("http://localhost:8080/");

            sendData = string.Empty;
            recvData = string.Empty;

            this.logTextBox = logTextBox;       // 텍스트박스
            this.clientCntLbl = clientCntLbl;   // 상태 표시 라벨
        }

        
        /// <summary>
        /// 비동기 서버 시작 및 클라이언트 연결 대기 및 데이터 송/수신
        /// </summary>
        public async Task StartServerAsync()
        {
            listener.Start();
            while (true)
            {
                HttpListenerContext context = await listener.GetContextAsync();

                if (context.Request.IsWebSocketRequest)
                {
                    HttpListenerWebSocketContext webSocketContext = await context.AcceptWebSocketAsync(null);
                    WebSocket socket = webSocketContext.WebSocket;
                    await AddLogAsync("STATE", "Client Connected!!");

                    // 클라이언트 연결을 컬렉션에 추가
                    clients.Add(socket);
                    await UpdateConnectedClientCountAsync();

                    // 각 클라이언트와의 통신을 별도의 스레드에서 처리
                    Task.Run(() => HandleClientAsync(socket));
                }
                else
                {
                    context.Response.StatusCode = 400;
                    context.Response.Close();
                }
            }
        }


        /// <summary>
        /// 클라이언트 송/수신 모듈
        /// 1초 간격으로 변경되는 Stock Exchange Hong Kong 데이터 전송
        /// </summary>
        /// <param name="socket">접속 클라이언트</param>
        private async Task HandleClientAsync(WebSocket socket)
        {
            #region
            try
            {
                while (socket.State == WebSocketState.Open)
                {
                    // 클라이언트가 연결되면 데이터를 전송 시작
                    string jsonData = JsonConvert.SerializeObject(sehk.DtSEHK);

                    foreach (var client in clients.ToList())
                    {
                        // 클라이언트로부터 응답을 기다림
                        string response = await ReceiveResponseAsync(client);

                        // 정상 수신을 받은 클라이언트에 데이터 전송
                        if (response == "SUCC")
                        {
                            string sendMsg = "SEHK@" + jsonData;
                            await SendDataAsync(client, sendMsg);
                            await AddLogAsync("RECEIVE", response); // Log
                        }
                        else
                        {
                            // 해당 클라이언트와의 연결을 종료함
                            await client.CloseAsync(WebSocketCloseStatus.NormalClosure, "Data reception error", CancellationToken.None);
                            clients.Remove(client);
                            await UpdateConnectedClientCountAsync();
                        }
                    }

                    await AddLogAsync("SEND", jsonData); // Log

                    // 1초 후 전송할 데이터 변경
                    await Task.Delay(TimeSpan.FromSeconds(1));
                    sehk.UpdateRandomDataOfSEHK();
                }
            }
            catch (Exception) {  }
            finally
            {
                // 클라이언트 연결을 컬렉션에서 제거
                clients.Remove(socket);
                await UpdateConnectedClientCountAsync();
            }
            #endregion
        }


        /// <summary>
        /// 데이터 수신부
        /// </summary>
        /// <param name="socket">접속 클라이언트</param>
        private async Task<string> ReceiveResponseAsync(WebSocket socket)
        {
            byte[] buffer = new byte[4096];
            string response = "";

            WebSocketReceiveResult result = await socket.ReceiveAsync(new ArraySegment<byte>(buffer), CancellationToken.None);
            if (result.MessageType == WebSocketMessageType.Text)
            {
                response = Encoding.UTF8.GetString(buffer, 0, result.Count);
            }

            return response;
        }


        /// <summary>
        /// 데이터 송신부
        /// </summary>
        /// <param name="socket">접속 클라이언트</param>
        /// <param name="data">송신 데이터</param>
        public async Task SendDataAsync(WebSocket socket, string data)
        {
            if (socket != null && socket.State == WebSocketState.Open)
            {
                byte[] buffer = Encoding.UTF8.GetBytes(data);
                await socket.SendAsync(new ArraySegment<byte>(buffer), WebSocketMessageType.Text, true, CancellationToken.None);
            }
        }


        /// <summary>
        /// 서버 로그 기록(TextBox)
        /// </summary>
        /// <param name="type"></param>
        /// <param name="message"></param>
        public async Task AddLogAsync(string type, string message)
        {
            // 비동기 작업에서 UI로 로그를 추가
            if (logTextBox != null)
            {
                logTextBox.Invoke(new Action(() =>
                {
                    logTextBox.AppendText("[" + DateTime.Now.ToString("HH:mm:ss.fff") + "] [" + type + "] : " + message + Environment.NewLine + Environment.NewLine);
                }));
            }
        }


        /// <summary>
        /// 연결된 클라이언트 개수 업데이트(Label)
        /// </summary>
        public async Task UpdateConnectedClientCountAsync()
        {
            // 연결된 클라이언트 라벨 업데이트
            if (clientCntLbl != null)
            {
                clientCntLbl.Invoke(new Action(() =>
                {
                    clientCntLbl.Text = "[연결 개수] " + clients.Count;
                }));
            }
        }


    }


}
