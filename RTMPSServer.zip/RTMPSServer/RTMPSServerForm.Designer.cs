﻿namespace RTMPSServer
{
    partial class RTMPSServerForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.timer = new System.Windows.Forms.Timer(this.components);
            this.lbl_state = new System.Windows.Forms.Label();
            this.lbl_connCnt = new System.Windows.Forms.Label();
            this.txtBox_log = new System.Windows.Forms.TextBox();
            this.pnl_top = new System.Windows.Forms.Panel();
            this.pnl_topLeft = new System.Windows.Forms.Panel();
            this.pnl_middle = new System.Windows.Forms.Panel();
            this.pnl_bottom = new System.Windows.Forms.Panel();
            this.pnl_bottomFill = new System.Windows.Forms.Panel();
            this.pnl_buttonMargin2 = new System.Windows.Forms.Panel();
            this.btn_clear = new System.Windows.Forms.Button();
            this.pnl_buttonMargin = new System.Windows.Forms.Panel();
            this.pnl_bottomMargin2 = new System.Windows.Forms.Panel();
            this.pnl_bottomMargin = new System.Windows.Forms.Panel();
            this.pnl_top.SuspendLayout();
            this.pnl_topLeft.SuspendLayout();
            this.pnl_middle.SuspendLayout();
            this.pnl_bottom.SuspendLayout();
            this.pnl_bottomFill.SuspendLayout();
            this.SuspendLayout();
            // 
            // timer
            // 
            this.timer.Interval = 1000;
            // 
            // lbl_state
            // 
            this.lbl_state.AutoSize = true;
            this.lbl_state.Font = new System.Drawing.Font("맑은 고딕", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbl_state.Location = new System.Drawing.Point(12, 18);
            this.lbl_state.Name = "lbl_state";
            this.lbl_state.Size = new System.Drawing.Size(197, 37);
            this.lbl_state.TabIndex = 0;
            this.lbl_state.Text = "서버 실행 대기";
            // 
            // lbl_connCnt
            // 
            this.lbl_connCnt.AutoSize = true;
            this.lbl_connCnt.Location = new System.Drawing.Point(12, 66);
            this.lbl_connCnt.Name = "lbl_connCnt";
            this.lbl_connCnt.Size = new System.Drawing.Size(71, 15);
            this.lbl_connCnt.TabIndex = 1;
            this.lbl_connCnt.Text = "[연결 개수] ";
            // 
            // txtBox_log
            // 
            this.txtBox_log.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtBox_log.Location = new System.Drawing.Point(0, 0);
            this.txtBox_log.Multiline = true;
            this.txtBox_log.Name = "txtBox_log";
            this.txtBox_log.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtBox_log.Size = new System.Drawing.Size(958, 322);
            this.txtBox_log.TabIndex = 2;
            // 
            // pnl_top
            // 
            this.pnl_top.Controls.Add(this.pnl_topLeft);
            this.pnl_top.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnl_top.Location = new System.Drawing.Point(0, 0);
            this.pnl_top.Name = "pnl_top";
            this.pnl_top.Size = new System.Drawing.Size(958, 100);
            this.pnl_top.TabIndex = 3;
            // 
            // pnl_topLeft
            // 
            this.pnl_topLeft.Controls.Add(this.lbl_state);
            this.pnl_topLeft.Controls.Add(this.lbl_connCnt);
            this.pnl_topLeft.Dock = System.Windows.Forms.DockStyle.Left;
            this.pnl_topLeft.Location = new System.Drawing.Point(0, 0);
            this.pnl_topLeft.Name = "pnl_topLeft";
            this.pnl_topLeft.Size = new System.Drawing.Size(320, 100);
            this.pnl_topLeft.TabIndex = 2;
            // 
            // pnl_middle
            // 
            this.pnl_middle.Controls.Add(this.txtBox_log);
            this.pnl_middle.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnl_middle.Location = new System.Drawing.Point(0, 100);
            this.pnl_middle.Name = "pnl_middle";
            this.pnl_middle.Size = new System.Drawing.Size(958, 322);
            this.pnl_middle.TabIndex = 4;
            // 
            // pnl_bottom
            // 
            this.pnl_bottom.Controls.Add(this.pnl_bottomFill);
            this.pnl_bottom.Controls.Add(this.pnl_bottomMargin2);
            this.pnl_bottom.Controls.Add(this.pnl_bottomMargin);
            this.pnl_bottom.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnl_bottom.Location = new System.Drawing.Point(0, 422);
            this.pnl_bottom.Name = "pnl_bottom";
            this.pnl_bottom.Size = new System.Drawing.Size(958, 37);
            this.pnl_bottom.TabIndex = 5;
            // 
            // pnl_bottomFill
            // 
            this.pnl_bottomFill.Controls.Add(this.pnl_buttonMargin2);
            this.pnl_bottomFill.Controls.Add(this.btn_clear);
            this.pnl_bottomFill.Controls.Add(this.pnl_buttonMargin);
            this.pnl_bottomFill.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnl_bottomFill.Location = new System.Drawing.Point(0, 5);
            this.pnl_bottomFill.Name = "pnl_bottomFill";
            this.pnl_bottomFill.Size = new System.Drawing.Size(958, 29);
            this.pnl_bottomFill.TabIndex = 2;
            // 
            // pnl_buttonMargin2
            // 
            this.pnl_buttonMargin2.Dock = System.Windows.Forms.DockStyle.Left;
            this.pnl_buttonMargin2.Location = new System.Drawing.Point(88, 0);
            this.pnl_buttonMargin2.Name = "pnl_buttonMargin2";
            this.pnl_buttonMargin2.Size = new System.Drawing.Size(3, 29);
            this.pnl_buttonMargin2.TabIndex = 2;
            // 
            // btn_clear
            // 
            this.btn_clear.Dock = System.Windows.Forms.DockStyle.Left;
            this.btn_clear.Location = new System.Drawing.Point(5, 0);
            this.btn_clear.Name = "btn_clear";
            this.btn_clear.Size = new System.Drawing.Size(83, 29);
            this.btn_clear.TabIndex = 2;
            this.btn_clear.Text = "삭제";
            this.btn_clear.UseVisualStyleBackColor = true;
            this.btn_clear.Click += new System.EventHandler(this.btn_clear_Click);
            // 
            // pnl_buttonMargin
            // 
            this.pnl_buttonMargin.Dock = System.Windows.Forms.DockStyle.Left;
            this.pnl_buttonMargin.Location = new System.Drawing.Point(0, 0);
            this.pnl_buttonMargin.Name = "pnl_buttonMargin";
            this.pnl_buttonMargin.Size = new System.Drawing.Size(5, 29);
            this.pnl_buttonMargin.TabIndex = 1;
            // 
            // pnl_bottomMargin2
            // 
            this.pnl_bottomMargin2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnl_bottomMargin2.Location = new System.Drawing.Point(0, 34);
            this.pnl_bottomMargin2.Name = "pnl_bottomMargin2";
            this.pnl_bottomMargin2.Size = new System.Drawing.Size(958, 3);
            this.pnl_bottomMargin2.TabIndex = 2;
            // 
            // pnl_bottomMargin
            // 
            this.pnl_bottomMargin.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnl_bottomMargin.Location = new System.Drawing.Point(0, 0);
            this.pnl_bottomMargin.Name = "pnl_bottomMargin";
            this.pnl_bottomMargin.Size = new System.Drawing.Size(958, 5);
            this.pnl_bottomMargin.TabIndex = 1;
            // 
            // RTMPSServerForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(958, 459);
            this.Controls.Add(this.pnl_bottom);
            this.Controls.Add(this.pnl_middle);
            this.Controls.Add(this.pnl_top);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "RTMPSServerForm";
            this.Text = "Server";
            this.Load += new System.EventHandler(this.RTMPSServerForm_Load);
            this.pnl_top.ResumeLayout(false);
            this.pnl_topLeft.ResumeLayout(false);
            this.pnl_topLeft.PerformLayout();
            this.pnl_middle.ResumeLayout(false);
            this.pnl_middle.PerformLayout();
            this.pnl_bottom.ResumeLayout(false);
            this.pnl_bottomFill.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Timer timer;
        private Label lbl_state;
        private Label lbl_connCnt;
        private TextBox txtBox_log;
        private Panel pnl_top;
        private Panel pnl_topLeft;
        private Panel pnl_middle;
        private Panel pnl_bottom;
        private Panel pnl_bottomFill;
        private Button btn_clear;
        private Panel pnl_buttonMargin;
        private Panel pnl_bottomMargin;
        private Panel pnl_bottomMargin2;
        private Panel pnl_buttonMargin2;
    }
}