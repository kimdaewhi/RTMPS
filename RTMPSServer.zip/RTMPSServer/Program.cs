namespace RTMPSServer
{
    internal static class Program
    {
        static Mutex mutex = new Mutex(true, "{00063D1A-CF1F-4D5D-8922-78316FE67259");

        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            // ���ؽ� ȹ�� �� �ߺ� ���� ����
            if (mutex.WaitOne(TimeSpan.Zero, true))
            {
                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
                // To customize application configuration such as set high DPI settings or default font,
                // see https://aka.ms/applicationconfiguration.
                ApplicationConfiguration.Initialize();
                Application.Run(new RTMPSServerForm());
                mutex.ReleaseMutex();
            }
            else
            {
                MessageBox.Show("���ø����̼��� �̹� ���� ���Դϴ�.", "���", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
    }
}