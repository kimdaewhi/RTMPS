﻿namespace RTMPSClient
{
    partial class ClientForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnl_bottom = new System.Windows.Forms.Panel();
            this.dgv_SEHK = new System.Windows.Forms.DataGridView();
            this.pnl_top = new System.Windows.Forms.Panel();
            this.pnl_topLeft = new System.Windows.Forms.Panel();
            this.lbl_name = new System.Windows.Forms.Label();
            this.pnl_bottom.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_SEHK)).BeginInit();
            this.pnl_top.SuspendLayout();
            this.pnl_topLeft.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnl_bottom
            // 
            this.pnl_bottom.Controls.Add(this.dgv_SEHK);
            this.pnl_bottom.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnl_bottom.Location = new System.Drawing.Point(0, 100);
            this.pnl_bottom.Name = "pnl_bottom";
            this.pnl_bottom.Size = new System.Drawing.Size(664, 291);
            this.pnl_bottom.TabIndex = 4;
            // 
            // dgv_SEHK
            // 
            this.dgv_SEHK.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_SEHK.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgv_SEHK.Location = new System.Drawing.Point(0, 0);
            this.dgv_SEHK.Name = "dgv_SEHK";
            this.dgv_SEHK.RowTemplate.Height = 25;
            this.dgv_SEHK.Size = new System.Drawing.Size(664, 291);
            this.dgv_SEHK.TabIndex = 0;
            this.dgv_SEHK.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.dgv_SEHK_CellFormatting);
            // 
            // pnl_top
            // 
            this.pnl_top.Controls.Add(this.pnl_topLeft);
            this.pnl_top.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnl_top.Location = new System.Drawing.Point(0, 0);
            this.pnl_top.Name = "pnl_top";
            this.pnl_top.Size = new System.Drawing.Size(664, 100);
            this.pnl_top.TabIndex = 5;
            // 
            // pnl_topLeft
            // 
            this.pnl_topLeft.Controls.Add(this.lbl_name);
            this.pnl_topLeft.Dock = System.Windows.Forms.DockStyle.Left;
            this.pnl_topLeft.Location = new System.Drawing.Point(0, 0);
            this.pnl_topLeft.Name = "pnl_topLeft";
            this.pnl_topLeft.Size = new System.Drawing.Size(478, 100);
            this.pnl_topLeft.TabIndex = 0;
            // 
            // lbl_name
            // 
            this.lbl_name.AutoSize = true;
            this.lbl_name.Font = new System.Drawing.Font("맑은 고딕", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lbl_name.Location = new System.Drawing.Point(12, 18);
            this.lbl_name.Name = "lbl_name";
            this.lbl_name.Size = new System.Drawing.Size(152, 37);
            this.lbl_name.TabIndex = 1;
            this.lbl_name.Text = "클라이언트";
            // 
            // ClientForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(664, 391);
            this.Controls.Add(this.pnl_bottom);
            this.Controls.Add(this.pnl_top);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "ClientForm";
            this.Text = "Client";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.ClientForm_FormClosed);
            this.pnl_bottom.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_SEHK)).EndInit();
            this.pnl_top.ResumeLayout(false);
            this.pnl_topLeft.ResumeLayout(false);
            this.pnl_topLeft.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private Panel pnl_bottom;
        private DataGridView dgv_SEHK;
        private Panel pnl_top;
        private Panel pnl_topLeft;
        private Label lbl_name;
    }
}