﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.WebSockets;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

#pragma warning disable 4014

namespace RTMPSClient
{
    internal class WebSocketClient
    {
        private ClientWebSocket clientWebSocket;        // WebSocket 통신
        string receiveMsg;                              // 서버 수신 메시지

        public string ReceiveMsg { get { return receiveMsg; } }

        public WebSocketClient() 
        {
            receiveMsg = string.Empty;
            clientWebSocket = new ClientWebSocket();
        }


        /// <summary>
        /// 서버 연결 및 데이터 수신
        /// </summary>
        public async Task ConnectServerAsync()
        {
            try
            {
                Uri serverUri = new Uri("ws://localhost:8080");

                // 연결 시도 및 서버 응답 없을 시 
                while (true)
                {
                    if (clientWebSocket.State != WebSocketState.Open)
                    {
                        // 연결이 끊긴 경우 다시 연결 시도
                        await clientWebSocket.ConnectAsync(serverUri, CancellationToken.None);

                        if (clientWebSocket.State == WebSocketState.Open)
                        {
                            string sendMsg = "SUCC";
                            await SendDataWithResponseAsync(sendMsg);

                            while (true)
                            {
                                // 서버로부터 응답 수신 및 처리
                                string responseMsg = await ReceiveDataAsync(clientWebSocket);

                                // 정상적으로 데이터 수신 시 서버에 데이터 요청
                                if (responseMsg.Split('@')[0].ToString() == "SEHK")
                                {
                                    receiveMsg = responseMsg.Split('@')[1].ToString();

                                    sendMsg = "SUCC";
                                    await SendDataWithResponseAsync(sendMsg);
                                }
                                else
                                {
                                    // 클라이언트가 서버에 재요청
                                    break;
                                }
                            }
                        }
                    }
                    else if (clientWebSocket.State == WebSocketState.Aborted)
                    {
                        break;
                    }

                    // 서버와 연결 상태를 주기적으로 확인
                    await Task.Delay(TimeSpan.FromSeconds(3));
                }

            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.Message);
            }
        }


        /// <summary>
        /// 데이터 수신부
        /// </summary>
        /// <param name="clientWebSocket"></param>
        /// <returns></returns>
        private async Task<string> ReceiveDataAsync(ClientWebSocket clientWebSocket)
        {
            try
            {
                byte[] buffer = new byte[4096];
                string message = "";

                // WebSocket 서버로부터 받은 결과
                WebSocketReceiveResult result = await clientWebSocket.ReceiveAsync(new ArraySegment<byte>(buffer), CancellationToken.None);
                if (result.MessageType == WebSocketMessageType.Text)
                {
                    message = Encoding.UTF8.GetString(buffer, 0, result.Count);
                }
                return message;
            }
            catch (WebSocketException)
            {
                // 서버와의 연결이 끊김 또는 수신 오류 처리
                return "SERVERERROR";
            }
        }


        /// <summary>
        /// 데이터 송신부
        /// </summary>
        /// <param name="data">서버 송신 데이터</param>
        public async Task SendDataWithResponseAsync(string data)
        {
            if (clientWebSocket != null && clientWebSocket.State == WebSocketState.Open)
            {
                byte[] buffer = Encoding.UTF8.GetBytes(data);
                await clientWebSocket.SendAsync(new ArraySegment<byte>(buffer), WebSocketMessageType.Text, true, CancellationToken.None);
            }
        }


        /// <summary>
        /// 클라이언트 연결 종료
        /// </summary>
        public async Task DisconnectAsync()
        {
            if (clientWebSocket.State == WebSocketState.Open)
            {
                // WebSocket 연결을 닫습니다.
                await clientWebSocket.CloseAsync(WebSocketCloseStatus.NormalClosure, "Connection closed by client", CancellationToken.None);
            }
        }



    }
}
